#!/usr/bin/env python
# coding: utf-8

# In[24]:

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

def preprocess():
	x_train=pd.read_csv('x_train.csv')
	x_test=pd.read_csv('x_test.csv')
	y_train=pd.read_csv('y_train.csv')
	y_test=pd.read_csv('y_test.csv')
	x_train=x_train.to_numpy()
	x_test=x_test.to_numpy()
	y_train=y_train.to_numpy()
	y_test=y_test.to_numpy()
	return x_train,y_train,x_test,y_test

x_train,y_train,x_test,y_test = preprocess()

specification_1A= MLPClassifier(hidden_layer_sizes=(32), max_iter=200, alpha=0.01,solver='sgd', verbose=False,  random_state=21)

specification_1A.fit(x_train, y_train)
y_pred_1A_train= specification_1A.predict(x_train)
y_pred_1A_test= specification_1A.predict(x_test)
print("Part_2, Specification_1A : ")
print("train_accuracy is = ",round(accuracy_score(y_train, y_pred_1A_train)*100,2),"%")
print("test_accuracy is = ",round(accuracy_score(y_test, y_pred_1A_test)*100,2),"%")
print("")


specification_1B= MLPClassifier(hidden_layer_sizes=(64,32), max_iter=200, alpha=0.01,solver='sgd', verbose=False,  random_state=21)

specification_1B.fit(x_train, y_train)
y_pred_1B_train = specification_1B.predict(x_train)
y_pred_1B_test= specification_1B.predict(x_test)
print("Part_2,  Specification_1B : ")
print("train_accuracy is = ",round(accuracy_score(y_train, y_pred_1B_train)*100,2),"%")
print("test accuracy = ",round(accuracy_score(y_test, y_pred_1B_test)*100,2),"%")

