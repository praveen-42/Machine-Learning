#!/usr/bin/env python
# coding: utf-8

# In[9]:


#!/usr/bin/env python
# coding: utf-8

# In[11]:


#!/usr/bin/env python
# coding: utf-8

# In[131]:

%matplotlib inline
import warnings
warnings.filterwarnings('ignore')
import copy
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.utils import shuffle
import matplotlib.pyplot as plt

def preprocess():
	x_train=pd.read_csv('x_train.csv')
	x_test=pd.read_csv('x_test.csv')
	y_train=pd.read_csv('y_train.csv')
	y_test=pd.read_csv('y_test.csv')
	x_train=x_train.to_numpy()
	x_test=x_test.to_numpy()
	y_train=y_train.to_numpy()
	y_test=y_test.to_numpy()
	return x_train,y_train,x_test,y_test


def initialize_parameters_deep(layer_dimensions):  
    parameters = {}
    
    # number of layers in the network
    L = len(layer_dimensions) 

    for l in range(1, L):
        parameters['W' + str(l)] = np.random.uniform(-1,1,(layer_dimensions[l-1], layer_dimensions[l]))
        parameters['B' + str(l)] = np.zeros((1,layer_dimensions[l]))
        
    return parameters


# Activation Functions and its derivatives
def sigmoid_function(Z):
    return 1/(1 + np.exp(-Z))

def sigmoid_derivative_function(Z):
    return Z * (1 - Z)


def relu_function(Z):
    R = np.maximum(0, Z)
    return R

def relu_derivative_function(Z):
    Z[Z >= 0] = 1
    Z[Z < 0]  = 0
    return Z


def softmax_function(Z):
    exps = np.exp(Z - np.max(Z, axis=1, keepdims=True))
    return exps/np.sum(exps, axis=1, keepdims=True)

def cross_entropy_function(pred, real):
    n_samples = real.shape[0]
    res = pred - real
    return res/n_samples

def error_function(pred, real):
    n_samples = real.shape[0]
    logp = - np.log(pred[np.arange(n_samples), real.argmax(axis=1)])
    loss = np.sum(logp)/n_samples
    return loss

def random_mini_batches_function(X, Y, mini_batch_size = 32, seed = 0):
    """
    Creates a list of random minibatches from (X, Y)
    
    Arguments:
    X -- input data
    Y -- true "label" vector 
    mini_batch_size -- size of the mini-batches, integer
    
    Returns:
    mini_batches -- list of synchronous (mini_batch_X, mini_batch_Y)
    """
    
    np.random.seed(seed)            # To make your "random" minibatches the same as ours
    m = X.shape[0]                  # number of training examples
    mini_batches = []
        
    # Step 1: Shuffle (X, Y)
    permutation = list(np.random.permutation(m))
    shuffled_X = X[permutation,:]
    shuffled_Y = Y[permutation,:].reshape((m,1))

    # Step 2: Partition (shuffled_X, shuffled_Y). Minus the end case.
    num_complete_minibatches = math.floor(m/mini_batch_size) # number of mini batches of size mini_batch_size in your partitionning
    for k in range(0, num_complete_minibatches):
        ### START CODE HERE ### (approx. 2 lines)
        mini_batch_X = shuffled_X[:,k * mini_batch_size:(k + 1) * mini_batch_size]
        mini_batch_Y = shuffled_Y[:,k * mini_batch_size:(k + 1) * mini_batch_size]
        ### END CODE HERE ###
        mini_batch = (mini_batch_X, mini_batch_Y)
        mini_batches.append(mini_batch)
    
    # Handling the end case (last mini-batch < mini_batch_size)
    if m % mini_batch_size != 0:
        ### START CODE HERE ### (approx. 2 lines)
        mini_batch_X = shuffled_X[:,num_complete_minibatches * mini_batch_size:]
        mini_batch_Y = shuffled_Y[:,num_complete_minibatches * mini_batch_size:]
        ### END CODE HERE ###
        mini_batch = (mini_batch_X, mini_batch_Y)
        mini_batches.append(mini_batch)
    
    return mini_batches

def Dataloader_function(X,Y):
    mini_batches=random_mini_batches(X,Y)
    return mini_batches




class network1_function:
    def __init__(self, X, Y):         #Function for intialization of parameters and weights
        self.X = X
        Hidden_neurons = 32
        self.learning_rate = 0.01
        input_dimension = X.shape[1]
        output_dimension = Y.shape[1]
        layers_dims=[input_dimension,Hidden_neurons,output_dimension]
        parameters=initialize_parameters_deep(layers_dims)
        self.W1=parameters['W1']
        self.B1=parameters['B1']
        self.W2=parameters['W2']
        self.B2=parameters['B2']
        self.Y = Y

    def feedforward_function(self):
        Z1 = np.dot(self.X, self.W1) + self.B1
        self.A1 = sigmoid_function(Z1)
        Z2 = np.dot(self.A1, self.W2) + self.B2
        self.A2 = softmax_function(Z2)
        
    def backprop_function(self):
        LOSS = error_function(self.A2, self.Y)
        A2_delta = cross_entropy_function(self.A2, self.Y)  # W2
        Z1_delta = np.dot(A2_delta, self.W2.T)
        A1_delta = Z1_delta * sigmoid_derivative_function(self.A1) # W1

        self.W2 -= self.learning_rate * np.dot(self.A1.T, A2_delta)
        self.B2 -= self.learning_rate * np.sum(A2_delta, axis=0, keepdims=True)
        self.W1 -= self.learning_rate * np.dot(self.X.T, A1_delta)
        self.B1 -= self.learning_rate * np.sum(A1_delta, axis=0)

    def predict_function(self, value):
        self.X = value
        self.feedforward_function()
        return self.A2.argmax()


class network2_function:
    def __init__(self, X, Y):
        self.X = X
        Hidden_neurons1 = 64
        Hidden_neurons2 = 32
        self.learning_rate = 0.01
        input_dimension = X.shape[1]
        output_dimension = Y.shape[1]
        layers_dims=[input_dimension,Hidden_neurons1,Hidden_neurons2,output_dimension]
        parameters=initialize_parameters_deep(layers_dims)
        self.W1=parameters['W1']
        self.B1=parameters['B1']
        self.W2=parameters['W2']
        self.B2=parameters['B2']
        self.W3=parameters['W3']
        self.B3=parameters['B3']
        self.Y = Y

    def feedforward_function(self):
        Z1 = np.dot(self.X, self.W1) + self.B1
        self.A1 = relu_function(Z1)
        Z2 = np.dot(self.A1, self.W2) + self.B2
        self.A2 = relu_function(Z2)
        Z3 = np.dot(self.A2, self.W3) + self.B3
        self.A3 = softmax_function(Z3)
        
    def backprop_function(self):
        LOSS = error_function(self.A3, self.Y)
        #print('Error :', loss)
        A3_delta = cross_entropy_function(self.A3, self.Y) # W3
        Z2_delta = np.dot(A3_delta, self.W3.T)
        A2_delta = Z2_delta * relu_derivative_function(self.A2) # W2
        Z1_delta = np.dot(A2_delta, self.W2.T)
        A1_delta = Z1_delta * relu_derivative_function(self.A1) # W1

        self.W3 -= self.learning_rate * np.dot(self.A2.T, A3_delta)
        self.B3 -= self.learning_rate * np.sum(A3_delta, axis=0, keepdims=True)
        self.W2 -= self.learning_rate * np.dot(self.A1.T, A2_delta)
        self.B2 -= self.learning_rate * np.sum(A2_delta, axis=0)
        self.W1 -= self.learning_rate * np.dot(self.X.T, A1_delta)
        self.B1 -= self.learning_rate * np.sum(A1_delta, axis=0)

    def predict_function(self, value):
        self.X = value
        self.feedforward_function()
        return self.A3.argmax()
            
		

def get_accuracy_function(X, Y):
    accuracy = 0
    for xxx,yyy in zip(X, Y):
        model1 = copy.copy(model) 
        s = model1.predict_function(xxx)
        if s == np.argmax(yyy):
            accuracy +=1
    return accuracy/len(X)*100


x_train,y_train,x_test,y_test = preprocess()

# def Train1(X,Y):
#         model=network1_function(X,Y)
#         epochs=200
#         train1_=[]
#         test1_=[]
#         it1_=[]
#         for x in range(epochs):
#             model.feedforward_function()
#             model.backprop_function()
#             if x%10==0 and x!=0:
#                 train1_.append(get_accuracy_function(x_train,y_train))
#                 test1_.append(get_accuracy_function(x_test, y_test))
#                 it1_.append(x) 
#         return train1,test1,it1
# (train1_,test1_,it1_)= Train1(x_train,y_train)

model = network1_function(x_train, y_train)

train1=[]
test1=[]
it1=[]
epochs = 200
for x in range(epochs):
    model.feedforward_function()
    model.backprop_function()
    if x%10==0 and x!=0:
        train1.append(get_accuracy_function(x_train,y_train))
        test1.append(get_accuracy_function(x_test, y_test))
        it1.append(x) 

print("Part_1A :")
print("Training_accuracy is : ", round(get_accuracy_function(x_train, y_train),2),"%")
print("Test_accuracy is : ", round(get_accuracy_function(x_test, y_test),2),"%")
print()


model = network2_function(x_train, y_train)

train2=[]
test2=[]
it2=[]

epochs = 200
for x in range(epochs):
    model.feedforward_function()
    model.backprop_function()
    if x%10==0 and x!=0:
        train2.append(get_accuracy_function(x_train,y_train))
        test2.append(get_accuracy_function(x_test, y_test))
        it2.append(x) 

print("Part_1B :")
print("Training_accuracy is : ", round(get_accuracy_function(x_train, y_train),2),"%")
print("Test_accuracy is : ", round(get_accuracy_function(x_test, y_test),2),"%")


plt.plot(it1,train1, color = 'r')
plt.plot(it1,test1, color = 'y')
plt.legend(["train", "test"])
plt.title('Specification 1')
plt.ylabel('% accuracy')
plt.xlabel('iterations (per tens)')

plt.show()


plt.plot(it2,train2, color = 'r')
plt.plot(it2,test2, color = 'y')
plt.legend(["train", "test"])
plt.title('Specification 2')
plt.ylabel('% accuracy')
plt.xlabel('iterations (per tens)')

plt.show()


# In[ ]:





# In[ ]:





# In[ ]:




