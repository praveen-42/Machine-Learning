#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pd
import numpy as np
from sklearn.utils import shuffle


data = pd.read_csv('seeds_dataset.txt', sep = '\t', header = None)
data.head()
X_train = data.iloc[:,:-1]
Y_train = data.iloc[:, -1]
X_train = np.array(X_train)
Y_train = np.array(Y_train)

# Z-SCORE NORMALIZATION
mean = np.mean(X_train, axis = 0)
variance = np.var(X_train, axis = 0)
X_train = np.divide((X_train - mean), variance)

a=Y_train-1
b = np.zeros((a.size, a.max()+1))
b[np.arange(a.size),a] = 1
Y_train=b

X_train, Y_train = shuffle(X_train, Y_train)

p_train=int(X_train.shape[0]*0.8)
x_test = X_train[p_train:,:]
y_test = Y_train[p_train:,:]

x_train = X_train[:p_train,:]
y_train = Y_train[:p_train,:]
x_train=pd.DataFrame(x_train)
x_test=pd.DataFrame(x_test)
y_train=pd.DataFrame(y_train)
y_test=pd.DataFrame(y_test)
x_train.to_csv('x_train.csv',index=False)
x_test.to_csv('x_test.csv',index=False)
y_train.to_csv('y_train.csv',index=False)
y_test.to_csv('y_test.csv',index=False)





