1-> The codes are written in python and hence can be executed on any platforom.
2-> I am submitting 3 python files 
3-> Each file can be executed independently as i am submitting all the processed datas.
4-> Dataset_preparation.py file prepare the dataset by doing Z-score normalization and 
    one-hot vectorization and generates four file which are:
    a) x_train.csv
    b) x_test.csv
    c) y_train.csv
    d) y_test.csv
5-> part1.py is my model which includes both 2-Layer and 3_Layer models
    and it uses these above 4 csv files as input and gives output as mentioned in the assignment
6-> part2.py is sklearn model and also uses the above 4 files and gives output as mentioned in the assignment
     