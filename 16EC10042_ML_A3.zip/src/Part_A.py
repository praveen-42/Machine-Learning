#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import os
data=pd.read_csv('AllBooks_baseline_DTM_Labelled.csv')
data.head()


# In[2]:


data.shape


# In[3]:


import math
from IPython.display import clear_output


# In[4]:


data['output_label']=pd.Series(list(map(lambda x: x.split('_')[0],data.iloc[:,0])))
data.drop('Unnamed: 0',axis=1,inplace=True)
data=data.drop(data.index[[13]],axis=0)
data.index=range(len(data))


# In[5]:


data.head()


# In[6]:


data.shape


# In[7]:


data.reset_index(inplace = True, drop = True)
m=len(data)
n=len(data.columns)


# In[8]:


print(m)
print(n)


# In[9]:


data.head()
df=data.copy()


# In[10]:


data.head()


# In[11]:


df_copy=df.copy()
m=len(df)
n=len(df.columns)

for i in range(n-1):
    df_t=len(df_copy[df_copy.iloc[:,i]>0])
    df.iloc[:,i]=pd.Series(list(map(lambda x: x*((np.log((1+m)/(1+df_t)))/(n-1)),df_copy.iloc[:,i])))
    print(i)
    clear_output(wait=True)


# In[12]:


df.head()


# In[14]:


processed_dataset=df.to_csv('processed_dataset.csv',header=True, index=False)


# In[ ]:




