#!/usr/bin/env python
# coding: utf-8

# # Part_E : Evaluation of the clusters

# In[2]:


import pandas as pd
import numpy as np
import os
df=pd.read_csv('processed_dataset.csv')
df.head()


# In[3]:


filenames=['agglomerative','agglomerative_reduced','kmeans','kmeans_reduced']

#function for calculating entropy of the output label of the passed dataframe
def getEntropy(df):
    gb=df.groupby('output_label')
    total=0
    count=[]
    for name,group in gb:
        val=len(group)
        count.append(val)
        total+=val
    ans=0
    for i in range(len(count)):
        p=count[i]/total
        ans+=-p*np.log2(p)
        
    return ans   

#function for calculating entropy of the clusters from the given output cluster file	
def getEntropyCluster(f):
    count=[]
    total=0
    for i in range(8):
        line=f.readline()
        val=len(line.split(','))
        total+=val
        count.append(val)
    f.seek(0,0)    
    ans=0
    for i in range(len(count)):
        p=count[i]/total
        ans+=-p*np.log2(p)
    return ans   

#function for calculating NMI score from the given output cluster file	
def getNMI(f):
    H_C=getEntropyCluster(f)
    cluster_list=[]
    count=[]
    total=0
    for i in range(8):
        line=f.readline()
        val=len(line.split(','))
        total+=val
        count.append(val)
        line=line.split(',')
        line=list(map(lambda x: int(x),line))
        cluster_list.append(line)
    H_YC=0
    f.seek(0,0)
    for i in range(8):
        H_YC+=(count[i]/total)*getEntropy(df.iloc[cluster_list[i],:])
    I_YC=H_Y-H_YC
    return (2*I_YC)/(H_Y+H_C)

#calculating entropy of outputs of the original dataset	
H_Y=getEntropy(df)

#calculating NMI score for all the cases/files and printing the score
for i in range(4):
    f=open(filenames[i]+'.txt','r+')
    score=getNMI(f)
    f.close()
    print(filenames[i]+'_score: '+str(int(score*10000)/10000))


# In[ ]:




