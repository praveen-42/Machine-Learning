#!/usr/bin/env python
# coding: utf-8

# # Task_B : Agglomerative Clustering
# 
# 

# In[1]:


import pandas as pd
import numpy as np
import os
df=pd.read_csv('processed_dataset.csv')
df.head()


# In[3]:


# for array of values
df_array=df.drop(['output_label'],axis=1).values
# for prestored cosine similarity values
dot_array=np.dot(df_array,df_array.T)


# In[4]:


dataframe_array=pd.DataFrame(df_array)
dataframe_dot_array=pd.DataFrame(dot_array)


# In[5]:


print(dataframe_array.shape)
print(df.shape)
print(dataframe_dot_array.shape)


# In[9]:


# Agglomerative Clustering
# m - number of training examples
# n - number of features in each training example


class qnode:
    def __init__(self,data_point_index_1,data_point_index_2,dist):
        self.data_point_index_1=data_point_index_1
        self.data_point_index_2=data_point_index_2
        self.dist=dist

class disjoint_sets:

    def __init__(self,m):
        self.parent=[]
        self.rank=[]
        for i in range(m): 
            self.parent.append(i)
            self.rank.append(0)


    def find_parent(self,i):
        if self.parent[i]==i: return i
        else:
            p=self.find_parent(self.parent[i])
            self.parent[i]=p
            return p

    def union(self,i,j):
        p_i=self.find_parent(i)
        p_j=self.find_parent(j)
        if(p_i==p_j) : return False
        else:
            if self.rank[p_i]<self.rank[p_j]: self.parent[p_i]=p_j
            elif self.rank[p_i]>self.rank[p_j]: self.parent[p_j]=p_i
            else:
                self.parent[p_i]=p_j
                self.rank[p_j]+=1
            return True  


def merge(A,p,q,r):
    L=[]
    R=[]
    for i in range(p,q+1): L.append(A[i])
    for j in range(q+1,r+1): R.append(A[j])
    n1=len(L)
    n2=len(R)
    assert(n1==q-p+1)
    assert(n2==r-q)
    k=p
    i=0
    j=0
    while i<n1 and j<n2:
        if L[i].dist<=R[j].dist:
            A[k]=L[i]
            i+=1
        else:
            A[k]=R[j]
            j+=1
        k+=1
    while i<n1:
        A[k]=L[i]
        k+=1
        i+=1
    while j<n2:
        A[k]=R[j]
        k+=1
        j+=1

def mergeSort(A,p,r):
    if p<r:
        q=(p+r)//2
        mergeSort(A,p,q)
        mergeSort(A,q+1,r)
        merge(A,p,q,r)





path=os.getcwd()
parent=os.path.dirname(path)

X=dot_array

dist=np.exp(-(X @ X.T))


L=[]
for i in range(X.shape[0]):
    for j in range(i+1,X.shape[0]):
        L.append(qnode(i,j,dist[i,j]))
mergeSort(L,0,len(L)-1)


m,n=X.shape

clusters=disjoint_sets(m)

num_clusters=m
k=0
while num_clusters!=8 and k<len(L):
    node=L[k]
    i1=node.data_point_index_1
    i2=node.data_point_index_2	
    if clusters.union(i1,i2): num_clusters-=1
    k+=1

cluster_parents=set()
for i in range(m):
     cluster_parents.add(clusters.find_parent(i))

i=0
d=dict()
for c in cluster_parents:
    d[c]=i
    i+=1

cluster_labels=[[] for i in range(num_clusters)]
for i in range(m):
    p=clusters.find_parent(i)
    p=d[p]
    cluster_labels[p].append(i)

cluster_labels.sort()
for c in cluster_labels:
    print(c)
    print()

f=open('agglomerative.txt','w+')
#writing the 8 created clusters into the file 'agglomerative.txt'
for i in range(8):
    cluster_labels[i].sort()
    for j in range(len(cluster_labels[i])):
        f.write(str(cluster_labels[i][j]))
        if j!=len(cluster_labels[i])-1:
            f.write(',')
    f.write('\n')    
f.close()



# In[ ]:




