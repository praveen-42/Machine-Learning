1.The codes are written in python and hence can be executed on any platform supporting python like jupyter notebook,etc.
  and i am submitting both python code and its jupyter notebook version in the src code file.

2.It will be good if you have platform which support jupyter notebook file and it will be easier for you to check everything in one go.

3.Each part can be executed indepently.

4.Part_A will generate the required dataset(processed files) which will be used in all next parts.

5.NMI Scores:
  agglomerative_score: 0.0169
  agglomerative_reduced_score: 0.0187
  kmeans_score: 0.2034
  kmeans_reduced_score: 0.4276