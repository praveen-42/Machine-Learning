#!/usr/bin/env python
# coding: utf-8

# In[51]:


#Importing the required python libraries
import numpy as np
import pandas as pd
import random
import math
import matplotlib.pyplot as plt


# In[52]:


#Reading and importing the training and testing datasets
train=pd.read_csv('train.csv')
train_x=train.iloc[:,0].values
train_y=train.iloc[:,1].values
test=pd.read_csv('test.csv')
test_x=test.iloc[:,0].values
test_y=test.iloc[:,1].values


# In[53]:


#plotting the scattered points of training dataset and saving it
plt.scatter(train_x,train_y)
plt.xlabel('Features of the training dateset')
plt.ylabel('Labels of the training dataset')
plt.title('Scattered plot on training dataset')
plt.savefig('Scattered plot on training dateset.png')


# In[54]:


#plotting the scattered points of testing dataset and saving it
plt.scatter(test_x,test_y)
plt.xlabel('Features of the testing dataset')
plt.ylabel('Labels of the testing dataset')
plt.title('Scattered plot on testing dataset')
plt.savefig('Scattered plot on testing dateset.png')


# In[55]:


def x_polynomial(n,x):
    x_nom=[]
    for i in range(len(x)):
        p=[]
        for j in range(n+1):
            p+=[x[i]**j]
        x_nom.append(p)
    return np.array(x_nom)


# In[56]:


def hypothesis(theta,x):
    return np.dot(x,theta)


# In[57]:


def min_squ_error(theta,x,y):
    ans=0
    ans+=hypothesis(theta,x)
    error=np.mean((ans-y)**2)
    error/=2
    return error


# In[58]:


def gradient_descent(theta,x,y):
    ans=0
    ans+=hypothesis(theta,x)
    ans-=y
    ans= x.transpose()*ans
    return np.mean(ans,axis=1)


# In[59]:


def regression(theta,x,y,alpha,cutoff=1e-6):
    error1=0
    while True:
        next_error=min_squ_error(theta,x,y)
        if abs(next_error-error1)<=cutoff:
            break
        error1=next_error
        gradient=alpha*gradient_descent(theta,x,y)
        theta=np.subtract(theta, gradient)
    return theta


# In[60]:


train_error=[]
test_error=[]
for i in [1,2,3,4,5,6,7,8,9]:
    x1_train=x_polynomial(i,train_x)
    x1_test=x_polynomial(i,test_x)
    coef=np.random.randn(i+1)
    theta=regression(coef,x1_train,train_y,0.05)
    print(theta)
    train_error.append(np.mean((np.dot(x1_train, theta) - train_y)**2)/2)
    test_error.append(np.mean((np.dot(x1_test, theta) - test_y)**2)/2)
    plt.scatter(train_x,train_y,color='green',marker='o',label='training dataset',s=2)
    plt.scatter(train_x,np.dot(x1_train, theta),color='blue',marker='o',label='predicted Model (n='+str(i)+')',s=2)
    plt.xlabel('Feature')
    plt.ylabel('Label')
    plt.legend()
    plt.title('Scattered plot for  (n='+str(i)+')')
    plt.savefig('Scattered plot on predicted values for Model (n='+str(i)+') .png')
    plt.show()
    plt.clf()
print(test_error)


# In[61]:


print(test_error)
print(train_error)


# In[62]:


from numpy import asarray
from numpy import savetxt
savetxt('test_error for Model 1 to 9.csv', test_error, delimiter=',')
savetxt('train_error for Model 1 to 9.csv', train_error, delimiter=',')


# In[63]:


print(test_error)


# In[64]:


print(train_error)


# In[65]:


fig=plt.figure()
axes=fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot(range(1,10),test_error,color='blue',marker='o',label='Test Error')
axes.plot(range(1,10),train_error,color='green',marker='o',label='Train Error')
axes.set_xlabel('Degree of Polynomial(n)-->')
axes.set_ylabel('Error-->')
axes.set_title('(Train & Test) Set Error vs Degree of Polynomial(n)')
axes.legend()
plt.tight_layout()
plt.show()
fig.savefig('Training and Test Error.png')


# In[66]:


def min_squ_error1(theta,x,y,param,regtype):
    if(regtype==1):
        return min_squ_error(theta,x,y)+param*(np.sum(abs(theta)))
    elif(regtype==2):
        return min_squ_error(theta,x,y)+param*(np.sum(theta**2))


# In[67]:


def gradient_descent1(theta,x,y,param,regtype):
    return gradient_descent(theta,x,y)


# In[68]:


def regression1(theta,x,y,alpha,param,regtype,cutoff=1e-6):
    error1=0
    m=len(x)
    while True:
        next_error=min_squ_error1(theta,x,y,param,regtype)
        if abs(next_error-error1)<=cutoff :
            break
        error1=next_error
        gradient=gradient_descent1(theta,x,y,param,regtype)
        for i in range(len(theta)):
            ans=0
            if(regtype==1):
                if(theta[i]<0):
                    ans+=(-1*param)
                else:
                    ans+=param
            elif(regtype==2):
                ans+=(2*param*theta[i])
            ans+=gradient[i]
            ans*=alpha
            theta[i]-=ans
    return theta  


# In[69]:


train_error_lasso=[]
test_error_lasso=[]
final_theta=[]
for i in [2,6]:
    x1_train=x_polynomial(i,train_x)
    m=len(x1_train)
    x1_test=x_polynomial(i,test_x)
    train_param=[]
    test_param=[]
    for j in [0.25,0.5,0.75,1]:
        theta=np.random.randn(i+1)
        theta=regression1(theta,x1_train,train_y,0.05,j,1)
        train_param.append(np.mean((np.dot(x1_train,theta)-train_y)**2)/2+j*np.sum(abs(theta))/(2*m))
        test_param.append(np.mean((np.dot(x1_test,theta)-test_y)**2)/2+j*np.sum(abs(theta))/(2*m))
        final_theta.append(theta)
    train_error_lasso.append(train_param)
    test_error_lasso.append(test_param)
print(test_error_lasso)


# In[70]:


print(train_error_lasso)
print(test_error_lasso)


# In[71]:


fig=plt.figure()
axes=fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot([0.25,0.5,0.75,1],test_error_lasso[0],color='blue',marker='o',label='Test Error')
axes.plot([0.25,0.5,0.75,1],train_error_lasso[0],color='green',marker='o',label='Train Error')
axes.set_xlabel('Regularization constant(Lasso regression) for n=2 -->')
axes.set_ylabel('Error-->')
axes.set_title('(Train & Test) Set Error vs Regularization constant(Lasso regression) for n=2')
axes.legend()
plt.tight_layout()
plt.show()
fig.savefig('test_error_lasso for n=2.png')


# In[72]:


fig=plt.figure()
axes=fig.add_axes([0.1,0.1,0.8,0.8])
axes.plot([0.25,0.5,0.75,1],test_error_lasso[1],color='blue',marker='o',label='Test Error')
axes.plot([0.25,0.5,0.75,1],train_error_lasso[1],color='green',marker='o',label='Train Error')
axes.set_xlabel('Regularization constant(Lasso regression) for n=6 -->')
axes.set_ylabel('Error-->')
axes.set_title('(Train & Test) Set Error vs Regularization constant(Lasso regression) for n=6')
axes.legend()
plt.tight_layout()
plt.show()
fig.savefig('test_error_lasso for n=6.png')


# In[ ]:




