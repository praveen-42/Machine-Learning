>I am submitting both jupyter notebook(.ipynb) and python(.py) file for each of the 
 subpart of the question.
>Thinking that if evaluator is accustom of jupyter notebook then it will become very handy 
 and easy for them to understand my code.
>Each file can be executed independently. I have inserted the training and test data files 
 in all the subquestion of each question with it's result files, plots and images, source codes
 in jupyter notebook as well as in python file. 
>I have put each code in report as well so that it will be easier to evaluate the code and 
 see the results simultaneously with justification of all the question asked in the report.
>i have written the code in such a manner that the next part contains all the previous part codes.
 it means, the part 2_a file contains part 1_a and part 1_b code.
 and finally part 3_b contains all the initial part codes.