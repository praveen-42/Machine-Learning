#!/usr/bin/env python
# coding: utf-8

# In[2]:


#Importing the required python libraries
import numpy as np
import pandas as pd
import random
import math
import matplotlib.pyplot as plt


# In[4]:


#Reading and importing the training and testing datasets
train=pd.read_csv('train.csv')
train_x=train.iloc[:,0].values
train_y=train.iloc[:,1].values
test=pd.read_csv('test.csv')
test_x=test.iloc[:,0].values
test_y=test.iloc[:,1].values


# In[6]:


#plotting the scattered points of training dataset and saving it
plt.scatter(train_x,train_y)
plt.xlabel('Features of the training dateset')
plt.ylabel('Labels of the training dataset')
plt.title('Scattered plot on training dataset')
plt.savefig('Scattered plot on training dateset.png')


# In[7]:


#plotting the scattered points of testing dataset and saving it
plt.scatter(test_x,test_y)
plt.xlabel('Features of the testing dataset')
plt.ylabel('Labels of the testing dataset')
plt.title('Scattered plot on testing dataset')
plt.savefig('Scattered plot on testing dateset.png')


# In[8]:


def x_polynomial(n,x):
    x_nom=[]
    for i in range(len(x)):
        p=[]
        for j in range(n+1):
            p+=[x[i]**j]
        x_nom.append(p)
    return np.array(x_nom)


# In[9]:


def hypothesis(theta,x):
    return np.dot(x,theta)


# In[10]:


def min_squ_error(theta,x,y):
    ans=0
    ans+=hypothesis(theta,x)
    error=np.mean((ans-y)**2)
    error/=2
    return error


# In[11]:


def gradient_descent(theta,x,y):
    ans=0
    ans+=hypothesis(theta,x)
    ans-=y
    ans= x.transpose()*ans
    return np.mean(ans,axis=1)


# In[12]:


def regression(theta,x,y,alpha,cutoff=1e-6):
    error1=0
    while True:
        next_error=min_squ_error(theta,x,y)
        if abs(next_error-error1)<=cutoff:
            break
        error1=next_error
        gradient=alpha*gradient_descent(theta,x,y)
        theta=np.subtract(theta, gradient)
    return theta


# In[30]:


train_error=[]
test_error=[]
for i in [1,2,3,4,5,6,7,8,9]:
    x1_train=x_polynomial(i,train_x)
    x1_test=x_polynomial(i,test_x)
    coef=np.random.randn(i+1)
    theta=regression(coef,x1_train,train_y,0.05)
    print(theta)
    train_error.append(np.mean((np.dot(x1_train, theta) - train_y)**2)/2)
    test_error.append(np.mean((np.dot(x1_test, theta) - test_y)**2)/2)
    plt.scatter(train_x,train_y,color='green',marker='o',label='training dataset',s=2)
    plt.scatter(train_x,np.dot(x1_train, theta),color='blue',marker='o',label='predicted Model (n='+str(i)+')',s=2)
    plt.xlabel('Feature')
    plt.ylabel('Label')
    plt.legend()
    plt.title('Scattered plot for  (n='+str(i)+')')
    plt.savefig('Scattered plot on predicted values for Model (n='+str(i)+') .png')
    plt.show()
    plt.clf()
print(test_error)


# In[35]:


print(test_error)
print(train_error)


# In[37]:


from numpy import asarray
from numpy import savetxt
savetxt('test_error for Model 1 to 9.csv', test_error, delimiter=',')
savetxt('train_error for Model 1 to 9.csv', train_error, delimiter=',')


# In[ ]:




