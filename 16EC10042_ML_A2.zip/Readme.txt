---I am submitting three .ipynb file for each Tasks i.e Task1, Task2, Task3
---Task1 consists of generating datasetA and datasetB from redwine-quality.csv file, each to be
   used for Task2 and Task3 respectively
---Task2 have the codes and results of created Logistic Model and sklearn methods for Logistic 
   Regression with 3-folds cross validation part and datasetA is used here.
---Task3 have the codes and results of created Decision Tree Model and sklearn methods for decision
   tree classifier with 3-folds cross validation part and datasetB is used here.
---all Tasks have required comments against the functions used there.